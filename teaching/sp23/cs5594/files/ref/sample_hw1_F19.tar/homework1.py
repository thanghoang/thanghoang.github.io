#!/usr/bin/env python3

"""
This is a Python 3 program to compute n^3-8n+75 and n^2 and print out
early values, formatted one per line for a LaTeX table.
"""

import math

def h(n,b=-8,c=25):
    x=float(n)
    return x**3 + b*x**2+c

for n in range(0,21):
    print(n,"&",h(n,b=-8,c=75),"&",n**2)
    print("\\\\\\hline")
